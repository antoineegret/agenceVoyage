#CSS Avancé

##Les exercices de la partie 3 sont à réaliser dans le même fichier HTML « index.html ». Ce fichier doit :
	• avoir une structure html5 valide ;
	• être nommé Voyage & Co (Title);

##Exercice 1
Dans le fichier HTML, créer une balise header dans laquelle se trouve l’image header.jpg et un titre
de premier niveau. Reproduire l’image ci-dessous.
Le choix de la police est libre.

##Exercice 2
Réaliser la barre de navigation du site Voyage & Co. Elle doit comporter
	• 4 onglets :
	o Accueil
	o Destinations
	o Réservations
	o Contact
	• Un champ de recherche et un bouton « Rechercher ».

##Exercice 3
Créer un texte d’accueil de présentation de l’agence Voyage & Co. Ce texte doit être :
	• Sous le menu
	• S’intégrer dans un espace plus petit que la taille de l’écran
	• Avoir un fond coloré

##Exercice 4
Sur la même ligne afficher 3 blocs. Chaque bloc doit avoir :
	• 1 photo ;
	• 1 titre ;
	• 1 texte descriptif.

Bonus
Utiliser les media queries pour rendre votre page responsive avec un point de rupture à 480px.
